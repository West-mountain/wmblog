**Installation**

{{% alert title="Note" color="primary" %}}
Check system compatibility before proceeding.
{{% /alert %}}

1.  Download the installation files.

1.  Run the installation script
    
    `sudo sh install.sh`

1.  Test that your installation was successfully completed.

