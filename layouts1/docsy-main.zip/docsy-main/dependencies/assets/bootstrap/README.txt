This folder was added in order to work around a known bug in Go’s module management.
For details, please refer to: https://github.com/golang/go/issues/37397
